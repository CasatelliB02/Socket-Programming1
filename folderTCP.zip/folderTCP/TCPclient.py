from socket import *

# Server host and port
server_ip = '127.0.0.1'
serverPort = 8080

#Get name and number from the server/user 
name = input("Enter your name: ")
number = input("Enter a number between 1 & 100: ")

#Creating message to send to server 
client_message= f"Client of {name},{number}"

#Creating socket object 
client_socket = socket(AF_INET, SOCK_STREAM)

#Connecting to server
client_socket.connect((server_ip, serverPort))

#Client sending message to server
client_socket.send(client_message.encode())

#Receiving the message 
server_message = client_socket.recv(2048).decode()

# Extract server name and number from message
server_name, server_number = server_message.split(',')

# Calculate sum of client number and server number
total = int(number) + int(server_number)

#Print message to console 
print(f"Client name: {name}")
print(f"Server name: {server_name}")
print(f"Client Number: {number}")
print(f"Server Number: {server_number}")
print(f"Total: {total} ")


#close socket
client_socket.close()
from socket import *
import random

# Server host and port
server_ip = '127.0.0.1'
serverPort = 8080

#socket object
server_socket = socket(AF_INET,SOCK_STREAM)

#bind the socket to ip and port
server_socket.bind((server_ip,serverPort))

#listening for incoming connections 
server_socket.listen(1)
print ("The server is listening and ready to receive....")

while True:
     #Waiting for client to accept
     client_socket, client_address = server_socket.accept()

     #Receive the message
     client_message = client_socket.recv(2048).decode()

     #Get the name and number from message 
     client_name, client_number = client_message.split(',')

     #Generate random number between 1 and 100
     #using import random to generate a "random" number
     server_number = random.randint(1,100)

     #Calculate sum of client number and server number
     total = int(client_number) + server_number

     #Create message to send back to client 
     server_message = f"The server of John Q. Smith,{server_number}"

     #Send message back to the client
     client_socket.send(server_message.encode())

     #Printing message to console
     print(f"{client_name} connected from {client_address[0]}" )
     print(f"Server number is: {server_number}")
     print(f"Client Number is: {client_number}")
     print(f"Total: {total}")
     #close the socket
     client_socket.close()